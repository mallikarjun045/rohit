/* ------------ FOOD DATA ------------- */

const foodData = [
  { name: "Margherita Pizza", price: 199, image: "img/pizza1.jpg", category: "pizza" },
  { name: "Pepperoni Pizza", price: 249, image: "img/pizza2.jpg", category: "pizza" },
  { name: "Paneer Pizza", price: 229, image: "img/pizza3.jpg", category: "pizza" },

  { name: "Chicken Burger", price: 180, image: "img/burger1.jpg", category: "burger" },
  { name: "Veg Burger", price: 140, image: "img/burger2.jpg", category: "burger" },

  { name: "Cheese Sandwich", price: 110, image: "img/sandwich1.jpg", category: "sandwich" },
  { name: "Chicken Sandwich", price: 150, image: "img/sandwich2.jpg", category: "sandwich" },

  { name: "Paneer Biryani", price: 160, image: "img/veg1.jpg", category: "veg" },
  { name: "Masala Dosa", price: 80, image: "img/veg2.jpg", category: "veg" },

  { name: "Chicken Biryani", price: 200, image: "img/nonveg1.jpg", category: "nonveg" },
  { name: "Fried Chicken", price: 170, image: "img/nonveg2.jpg", category: "nonveg" }
];


/* ------------ LOAD MENU ------------- */

function loadMenu(categoryFilter = "all") {
  const container = document.getElementById("foodContainer");
  if (!container) return;

  container.innerHTML = "";

  foodData.forEach(item => {
    if (categoryFilter !== "all" && item.category !== categoryFilter) return;

    container.innerHTML += `
      <div class="food-card" data-category="${item.category}">
        <img src="${item.image}">
        <h3>${item.name}</h3>
        <p>₹${item.price}</p>
        <button class="add-to-cart-btn" onclick="addToCart('${item.name}', ${item.price}, '${item.image}')">Add to Cart</button>
      </div>
    `;
  });
}

document.addEventListener("DOMContentLoaded", () => loadMenu());

/* ------------ FILTERS ------------- */
document.querySelectorAll(".filter-btn").forEach(btn => {
  btn.addEventListener("click", () => {
      document.querySelector(".filter-btn.active")?.classList.remove("active");
      btn.classList.add("active");

      const category = btn.dataset.category;
      loadMenu(category);
  });
});

/* ---------- SEARCH ----------- */
const searchInput = document.getElementById("searchInput");
if (searchInput) {
  searchInput.addEventListener("input", () => {
    let value = searchInput.value.toLowerCase();
    let items = document.querySelectorAll(".food-card");

    items.forEach(card => {
      let name = card.querySelector("h3").innerText.toLowerCase();
      card.style.display = name.includes(value) ? "block" : "none";
    });
  });
}

/* ------------ CART ------------- */

let cart = JSON.parse(localStorage.getItem("cart")) || [];

function addToCart(name, price, image) {
  cart.push({ name, price, image });
  localStorage.setItem("cart", JSON.stringify(cart));
  updateCartCount();
  alert("Added to cart!");
}

function updateCartCount() {
  const count = document.querySelector(".cart-count");
  if (count) count.innerText = cart.length;
}
updateCartCount();

/* CART MODAL HANDLING */
const cartLink = document.getElementById("cartLink");
const cartModal = document.getElementById("cartModal");
const closeCart = document.getElementById("closeCart");

if (cartLink) {
  cartLink.onclick = () => {
    displayCartItems();
    cartModal.style.display = "flex";
  };
}

if (closeCart) {
  closeCart.onclick = () => cartModal.style.display = "none";
}

/* SHOW ITEMS IN CART MODAL */
function displayCartItems() {
  let cartItems = document.getElementById("cartItems");
  cartItems.innerHTML = "";

  let total = 0;

  cart.forEach((item, index) => {
    total += item.price;

    cartItems.innerHTML += `
      <div class="cart-item">
        <img src="${item.image}">
        <p>${item.name}</p>
        <p>₹${item.price}</p>
      </div>
    `;
  });

  document.getElementById("cartTotal").innerText = total;
}

/* CHECKOUT */
document.getElementById("checkoutBtn")?.addEventListener("click", () => {
  localStorage.setItem("cart", JSON.stringify(cart));
  window.location.href = "checkout.html";
});

/* -------- HOME RESTAURANT CLICK -------- */

function openRestaurant(category) {
  localStorage.setItem("restaurantCategory", category);
  window.location.href = "menu.html";
}

/* When menu loads, check if coming from home page */
if (localStorage.getItem("restaurantCategory")) {
  loadMenu(localStorage.getItem("restaurantCategory"));
  localStorage.removeItem("restaurantCategory");
}
